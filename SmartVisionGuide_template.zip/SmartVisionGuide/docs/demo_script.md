# Demo Script (2–3 minutes)

1) Start the app and show camera view.
2) Bring an object close:
   - audio: “Obstacle very close: <label>”
   - console: vibration duration
3) Move object farther:
   - “Obstacle ahead: <label>”
4) Next steps:
   - BLE cane integration
   - better distance estimation (depth/stereo)
   - real-world testing and safety disclaimers
