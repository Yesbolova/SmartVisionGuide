# Ethics & Privacy

- This is an assistive tool and may make mistakes.
- The user must be informed that guidance is advisory.

Recommended privacy principles:
- Prefer on-device processing
- Avoid storing personal data
- Do not share raw camera footage
